# import globalVar as globalVar
# import deinfo as deInfo

# globalVar.appendVar('headers',{"Cookie": deInfo.toCookie(deInfo.decodeInfo())})
