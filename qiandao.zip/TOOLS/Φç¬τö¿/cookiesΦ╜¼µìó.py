a = '''bubble: 0
msg: 单独
color: 16777215
mode: 1
fontsize: 25
rnd: 1625056859
roomid: 23002190
csrf: 290f59540b5d55f485ad655fbe44cbc2
csrf_token: 290f59540b5d55f485ad655fbe44cbc2'''
b = ''

for i in a.split('\n'):
    _ = i.split(': ')
    _1 = _[0]
    _2 = _[1]
    b = f"{b}\"{_1}\": \"{_2}\","

print(b)