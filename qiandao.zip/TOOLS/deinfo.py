import os
import json


def decodeInfo(host='bilibili'):
    if host == 'bilibili':
        info_json = {
            'DedeUserID': '441138692',
            'bili_jct': 'dc9e3dde921a72d73c40554fbdb870a2',
            'SESSDATA': 'b5dd52bd%2C1645931704%2Cf1b74%2A81'
        }
        return info_json
    elif host == '52pojie':
        return "__gads=ID=ea1efad911085c47-2234630bbbca00dd:T=1628297284:RT=1628297284:S=ALNI_MbQSPTisAwhCNN6wfP0W4AXOs8krQ; htVD_2132_saltkey=MBIh6xs8; htVD_2132_lastvisit=1631449358; htVD_2132_auth=bc0cgGQvQQRKmDbswpVo6gxPR1dFpRI7%2BT0kGLUc4Rd%2FxuZSjcsVitHmYWAeZ2JsZ4cW6oju496Pf8%2BPo%2BUScdi%2B19U; htVD_2132_connect_is_bind=1; htVD_2132_nofavfid=1; htVD_2132_smile=1D1; htVD_2132_sid=0; htVD_2132_ulastactivity=1633854291%7C0; htVD_2132_checkpm=1; htVD_2132_noticeTitle=1; Hm_lvt_46d556462595ed05e05f009cdafff31a=1631453049,1633592040,1633854232; htVD_2132_st_p=910954%7C1633854296%7Cde0df9bb73aa518d6d5bfd88d6496984; htVD_2132_visitedfid=24D16; htVD_2132_viewid=tid_1242951; htVD_2132_atarget=1; htVD_2132_st_t=910954%7C1633854321%7C6a35a9147806ff051051cc352b538307; htVD_2132_forum_lastvisit=D_24_1633854321; htVD_2132_lastcheckfeed=910954%7C1633854322; htVD_2132_checkfollow=1; Hm_lpvt_46d556462595ed05e05f009cdafff31a=1633854262; htVD_2132_lastact=1633854330%09home.php%09task"
    elif host == 'luogu':
        info_json = {
            '__client_id':'82fd189665f8c9f79034cbbd76f97f32ac2ae450',
            '_uid':'560948'
        }
        return toCookie(info_json)
    elif host == 'ikuuu':
        info_json = {
            'uid':'323950',
            'email':'deffield62%40gmail.com',
            'key':'c86e5805da454c2ac08442dc02457f9f95cb1b25fa189',
            'expire_in':'1637219033'
        }
        return toCookie(info_json)
    elif host == 'fishc':
        info_json = [
            {
                'username':"Burnling",
                'password':'jeQN*sYhD!3csyJ'
            },
            {
                'username':"zbn0312",
                'password':'ZBNzbn060312'
            }
        ]
        return info_json
    elif host == 'cnblog_my':
        info_json = {
            'umplus_uc_token':'1exyoioNQtuz9dYkFQMb6gw_3abbab9316a2489abe5739b3f9cf1e94'
        }
        return toCookie(info_json)


def toCookie(infoJ):
    _ = []
    for i in infoJ:
        _.append(str(i) + '=' + str(infoJ[i]))
    return '; '.join(_)
