global glb_dict
glb_dict = {}

def getVar(key_):
    return glb_dict.get(key_)

def appendVar(key_, value_):
    glb_dict[key_] = value_