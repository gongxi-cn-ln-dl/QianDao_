import TOOLS.deinfo as deInfo
import TOOLS.globalVar as globalVar
import requests

def get_info(data):
    _ = []
    for i in data:
        roomid = i.get('roomid')
        if roomid == None:
            continue
        _.append([i['uname'],i['medal_name'],roomid])
    return _

def get_fansMedal():
    info_list = []
    headers = {"Cookie": deInfo.toCookie(deInfo.decodeInfo())}
    url = 'https://api.live.bilibili.com/xlive/app-ucenter/v1/user/GetMyMedals'
    params = {
        'page': 1,
        'page_size': 10
    }
    res = requests.get(url, params=params, headers=headers)
    res_j = res.json()
    
    if res_j['code'] == 0:
        totalpages = res_j['data']['page_info']['total_page']

    for i in range(1,totalpages+1):
        params['page'] = i
        res = requests.get(url, params=params,headers=headers)
        res_j = res.json()
        info_list += get_info(res_j['data']['items'])
    info_dict = {}
    for i in info_list:
        info_dict[i[2]] = i[0]
    globalVar.appendVar("roomid_dict",info_dict)
    return info_dict
