import requests
import time
import re
import json
import random

import main_activities as mainA
import TOOLS.deinfo as deInfo
import TOOLS.globalVar as globalVar
import fans_medal as fmedal

time_start = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()+8*60*60))

def toHex(x):
    step1 = str(hex(x))[2:]
    step2 = step1
    if len(step2) == 1:
        return '0'+step2
    return step2

def randomColor():
    R = random.randint(0,255)
    G = random.randint(0,255)
    B = random.randint(0,255)
    r = toHex(R)
    g = toHex(G)
    b = toHex(B)
    return f'#{r}{g}{b}'

def pushMessage(dt:list):
    appID = 'wx4262aec423aed3a6'
    appsecret = '2b4c6295d0bdf4e2a928de6a1fbb9b7a'

    template_id_list = [
        'bdxkIkRsf4qRlJOceNV6Izd-9W_l9fq_IEFqTIlBMG8',
        'UqeZEIf36F_lPDet4u23pI3OEp9QCVHWbS4VCKiiPqA',
        'HorSKFFY7j8keeLTII2QUaQ4JlUg-8MoaShKV8zknlM'
        ]
    
    for i in range(len(dt)):
        data = {"touser": "ojWde6XD0k-sBc_LioUDbNlLcUR8","template_id": template_id_list[i],"data": dt[i]}
        print(data)
        access_token = requests.get(f'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={appID}&secret={appsecret}').json()['access_token']
        print(access_token)

        postUrl = f'https://api.weixin.qq.com/cgi-bin/message/template/send?access_token={access_token}'

        x = requests.post(postUrl, data=json.dumps(data))
        print(x.text)

# a = mainA.sendText()


def main_handler(event, context):
    b,c,d,e,f,ST = "","","","","",""
    try:
        b = mainA.DoSign_Bili()
    except BaseException as er:
        b = str(er)
    
    try:
        d = mainA.DoSign_52()
    except BaseException as er:
        d = str(er)
    
    try:
        c = mainA.sendText()
        successNum = len(re.findall('成功',c[0]))
        _ = c[1]
        t = []
        for i in _:
            __ = re.findall('在 (.*?) 的直播间发送弹幕失败',i,re.S)[0]
            t.append(__)
        ST = f'在{successNum}个直播间成功发送弹幕'+f'\n在 {"、".join(t)} 的直播间发送弹幕失败'

    except BaseException as er:
        c = str(er)
        ST = str(er)
    
    try:
        e = mainA.DoSign_luogu()
    except BaseException as er:
        e = str(er)
    
    try:
        f = mainA.Dosign_ikuuu()
    except BaseException as er:
        f = str(er)
    
    try:
        g = mainA.Dosign_fishc()
    except BaseException as er:
        g = str(er)

    try:
        h = mainA.blog()
    except BaseException as er:
        h = str(er)

    time_push = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()+8*60*60))

    color = randomColor()
    print(h)
    dt = [{
        'time_start': {'value': str(time_start), 'color': color},
        'time_push': {'value': str(time_push), 'color': color},
        'Dosign_luogu':{'value':e,'color':color},
        'Dosign_Bili': {'value': b, 'color': color},
        'live_fans_medal_Bili': {'value': ST, 'color': color}
    },
    {
        'Dosign_52pojie': {'value': d, 'color': color},
        'Dosign_iKuuu':{'value':f,'color':color},
        'Dosign_FishC':{'value':g,'color':color}
    },
    {
        'Yesterday_Date':{'value':time.strftime("%Y-%m-%d", time.localtime(time.time()+8*60*60-1*24*60*60)),'color':color},
        'Yesterday_PV':{'value':h['yesterday'][0],'color':color},
        'Yesterday_UV':{'value':h['yesterday'][1],'color':color},
        'Yesterday_IP':{'value':h['yesterday'][2],'color':color},
        'Yesterday_NUV':{'value':h['yesterday'][3],'color':color},
        'Yesterday_Ct':{'value':h['yesterday'][4],'color':color},

        'ALL_PV':{'value':h['all'][0],'color':color},
        'ALL_UV':{'value':h['all'][1],'color':color},
        'ALL_IP':{'value':h['all'][2],'color':color},
        'ALL_NUV':{'value':h['all'][3],'color':color},
        'ALL_Ct':{'value':h['all'][4],'color':color}
    }]

    pushMessage(dt)
    print(c)


# print(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()+8*60*60)))
# main_handler(0,0)
# print(randomColor())