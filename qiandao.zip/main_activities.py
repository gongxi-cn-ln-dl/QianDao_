# encoding=utf8
import random
import re
import time

import hashlib

import requests

import fans_medal as fmedal
import TOOLS.deinfo as deInfo

UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.366'

headers = {
    "Cookie": deInfo.toCookie(deInfo.decodeInfo()),
    'user-agent': UA
}
headers_52pojie = {
    "Cookie" : deInfo.decodeInfo('52pojie'),
    "User-Agent": UA,
    "Host": "www.52pojie.cn",
    'ContentType':'text/html;charset=gbk'
}

def DoSign_Bili():

    res = requests.get(
        'https://api.live.bilibili.com/xlive/web-ucenter/v1/sign/DoSign', headers=headers)
    print(headers)
    res.encoding = 'utf-8'

    res_j = res.json()
    print(res_j)
    res_data = res_j['data']
    if res_data:
        specialText = res_data['specialText']
        if specialText:
            specialText = f'\n特殊消息：{specialText}'
        re_text = f"已签到[{res_data['hadSignDays']}/{res_data['allDays']}]天，获得{res_data['text']}{specialText}"
        return re_text
    return res_j['message']

def sendText():
    texts = ''
    fail = []
    def get_rnd():
        return str(int(time.time()))

    def send(roomid: str, text: str):
        bili_jct = deInfo.decodeInfo()['bili_jct']
        data = {
            "bubble": "0",
            "msg": text,
            "color": "16777215",
            "mode": "1",
            "fontsize": "25",
            "rnd": get_rnd(),
            "roomid": roomid,
            "csrf": bili_jct,
            "csrf_token": bili_jct
        }
        url = 'https://api.live.bilibili.com/msg/send'
        res = requests.post(url, headers=headers, data=data).json()
        if res['code'] == 0:
            return 'success'
        return res

    info_dict = fmedal.get_fansMedal()
    for i in info_dict:
        try:
            rt = send(i, '好耶')
        except BaseException as e:
            texts += f'在 {info_dict[i]} 的直播间发送弹幕失败，失败原因:{e}\n'
            fail.append(f'在 {info_dict[i]} 的直播间发送弹幕失败，失败原因:{e}')
            continue
        stop_time = random.randint(1, 15)
        if rt == 'success':
            texts += f'在 {info_dict[i]} 的直播间成功发送弹幕\n'
        else:
            texts += f'在 {info_dict[i]} 的直播间发送弹幕失败，失败原因:{rt["message"]}\n'
            fail.append(f'在 {info_dict[i]} 的直播间发送弹幕失败，失败原因:{rt["message"]}')
        time.sleep(stop_time)

    return texts,fail

def DoSign_52():
    r = requests.session()
    r.get('https://www.52pojie.cn/home.php?mod=task&do=apply&id=2',headers=headers_52pojie)
    a = r.get('https://www.52pojie.cn/home.php?mod=task&do=draw&id=2',headers=headers_52pojie)

    _ = re.findall('<div id="messagetext"(.*?)</div>',a.text,re.S)[0]
    returnText = re.findall('<p>(.*?)</p>',_,re.S)[0]

    if "您需要先登录才能继续本操作"  in returnText: 
        return f"Cookie失效【{returnText}】"
    elif "恭喜"  in returnText:
        return "吾爱破解签到成功"
    elif "任务"  in returnText:
        return f"今日已经手动签到【{returnText}】"
    else:
        return f"吾爱破解签到失败【{returnText}】"

def DoSign_luogu():
    url_indexPage = 'https://www.luogu.com.cn/'
    url_doSign = 'https://www.luogu.com.cn/index/ajax_punch'

    cookie = deInfo.decodeInfo('luogu')
    headers = {
        'user-agent': UA,
        'referer': 'https://class.luogu.com.cn/',
        "Cookie" : cookie
    }
    
    _ = requests.get(url_indexPage,headers=headers).text
    csrf_token = re.findall('<meta name="csrf-token" content="(.*?)">',_,re.S)[0]

    headers = {
        'origin': 'https://www.luogu.com.cn',
        'referer': 'https://www.luogu.com.cn/',
        'user-agent': UA,
        "Cookie" : cookie,
        'x-csrf-token': csrf_token
    }

    _ = requests.post(url_doSign,headers=headers).json()
    print(_)
    if _['message']:
        return _['message']
    else:
        html = _['more']['html']
        days = re.findall("你已经在洛谷连续打卡了 <strong>\d{0,}<\/strong> 天<\/strong>",html,re.S)[0]
        days = re.findall("<strong>(.*?)<\/strong>",days,re.S)[0]
        text = f'打卡成功，你已经在洛谷连续打卡了 {days} 天'
        return text

def Dosign_ikuuu():
    host = 'https://ikuuu.live/'
    url_dosign = f'{host}user/checkin'

    headers = {
        'Cookie' : deInfo.decodeInfo('ikuuu'),
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36'
    }
    res = requests.post(url_dosign,headers=headers)
    res.encoding = 'utf-8'

    return res.json()['msg']

def Dosign_fishc():

    def login(userinfo:dict):
        username = userinfo['username']
        password = hashlib.md5(userinfo['password'].encode('gbk')).hexdigest()

        data = {
            'username': username,
            'password': password,
            'quickforward': 'yes',
            'handlekey': 'ls',
            'cookietime': '2592000'
        }
        headers = {
            'Host': 'fishc.com.cn',
            'Origin': 'https://fishc.com.cn',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
        }
        url_login = 'https://fishc.com.cn/member.php?mod=logging&action=login&loginsubmit=yes&infloat=yes&lssubmit=yes&inajax=1'
        res = requests.session()
        res.post(url_login,data=data,headers=headers)
        return res
    def signin():
        
        showid = 'JD_sign'
        pushtext = ''

        def p(userinfo:dict):
            res = login(userinfo)
            url = 'https://fishc.com.cn/plugin.php?id=k_misign:sign'
            formhash = res.get(url)
            formhash = re.findall('formhash=([a-z0-9]{0,8})', formhash.text, re.S)[0]

            url_signin = f'https://fishc.com.cn/plugin.php?id=k_misign:sign&operation=qiandao&formhash={formhash}&format=empty'
            url_signin = url_signin + '&inajax=1&ajaxtarget=' + showid

            a = res.get(url_signin).text
            backData = re.findall('CDATA\[(.*?)\]',a,re.S)
            return backData
        
        for index,i in enumerate(deInfo.decodeInfo('fishc')):
            print(i)
            backData = p(i)
            print(backData)
            if(backData == ['']):
                pushtext += f'第{index+1}个账号签到成功！\n'
            else:
                pushtext += f'{backData}\n'
        return pushtext
    pushtext = signin()
    return pushtext

def blog():
    url = f'https://web.umeng.com/main.php/'

    params = {
        'c':'site',
        'a':'overview',
        'ajax':'module=summary',
        'siteid':'1280638230',
        '_':str(int(time.time()*1000))
    }

    headers = {
        'cookie': deInfo.decodeInfo('cnblog_my')
    }

    req = requests.get(url=url,headers=headers,params=params).json()['data']
    if req.get('status')==False:
        return {'yesterday':["ERROR","ERROR","ERROR","ERROR","ERROR"],'all':["ERROR","ERROR","ERROR","ERROR","ERROR"]}
    req = req['summary']['items']
    print(req)
    yesterday = req[1]
    ALL = req[6]
    rt = {
        "yesterday":[
            yesterday['pv'],
            yesterday['uv'],
            yesterday['ip'],
            yesterday['newuv'],
            yesterday['session'],
        ],
        "all":[
            ALL['pv'],
            ALL['uv'],
            ALL['ip'],
            ALL['newuv'],
            ALL['session'],
        ]
    }
    print(rt)
    return rt

# a = blog()
# print(a)